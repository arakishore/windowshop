<?php

namespace Database\Seeders\MasterData;

use App\Models\ProductCategory;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class ProductCategorySeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::transaction(function (): void {
            $apparel = $this->createCategory('Apparel', null, 1);

            $men = $this->createCategory('Men', $apparel, 1);
            $this->createChildren($men, [
                'T-Shirts',
                'Shirts',
                'Polo T-Shirts',
                'Sweatshirts',
                'Jackets',
                'Jeans',
                'Trousers',
                'Shorts',
                'Track Pants',
                'Kurtas',
                'Kurta Sets',
                'Sherwanis',
                'Innerwear',
                'Sleepwear',
                'Winter Wear',
            ]);

            $women = $this->createCategory('Women', $apparel, 2);
            $this->createChildren($women, [
                'T-Shirts',
                'Tops',
                'Shirts',
                'Kurtis',
                'Kurta Sets',
                'Sarees',
                'Lehengas',
                'Dresses',
                'Jeans',
                'Leggings',
                'Skirts',
                'Trousers',
                'Innerwear',
                'Sleepwear',
                'Winter Wear',
            ]);

            $this->createCategory('Boys', $apparel, 3);
            $this->createCategory('Girls', $apparel, 4);
            $this->createCategory('Baby Clothing', $apparel, 5);
            $this->createCategory('Unisex', $apparel, 6);

            $footwear = $this->createCategory('Footwear', null, 2);
            $this->createChildren($footwear, [
                'Men',
                'Women',
                'Kids',
            ]);

            $electronics = $this->createCategory('Mobile & Electronics', null, 3);
            $this->createChildren($electronics, [
                'Mobile Phones',
                'Laptops',
                'Accessories',
                'Audio',
                'Smart Watches',
            ]);

            $beauty = $this->createCategory('Beauty & Cosmetics', null, 4);
            $this->createChildren($beauty, [
                'Makeup',
                'Skin Care',
                'Hair Care',
            ]);

            $jewellery = $this->createCategory('Jewellery & Accessories', null, 5);
            $this->createChildren($jewellery, [
                'Fashion Jewellery',
                'Bags',
                'Accessories',
            ]);

            $grocery = $this->createCategory('Grocery & Daily Needs', null, 6);
            $this->createChildren($grocery, [
                'Staples',
                'Snacks',
                'Beverages',
                'Personal Care',
                'Household',
            ]);

            $cafe = $this->createCategory('Cafe & Restaurant', null, 7);
            $this->createChildren($cafe, [
                'Beverages',
                'Fast Food',
                'Meals',
                'Bakery',
                'Desserts',
            ]);

            $home = $this->createCategory('Home & Furniture', null, 8);
            $this->createChildren($home, [
                'Furniture',
                'Home Decor',
                'Kitchen',
                'Dining',
                'Bedding',
            ]);

            $sports = $this->createCategory('Sports & Fitness', null, 9);
            $this->createChildren($sports, [
                'Fitness Equipment',
                'Sportswear',
                'Sports Shoes',
                'Accessories',
            ]);

            $books = $this->createCategory('Books & Stationery', null, 10);
            $this->createChildren($books, [
                'Books',
                'Notebooks',
                'Pens',
                'Art Supplies',
                'Office Supplies',
            ]);
            $this->createCategory('Other', null, 11);

            $this->ensureOtherChildForParentCategories();
        });
    }

    private function createChildren(ProductCategory $parent, array $names): void
    {
        foreach ($names as $index => $name) {
            $this->createCategory($name, $parent, $index + 1);
        }
    }

    private function createCategory(string $name, ?ProductCategory $parent, int $sortOrder): ProductCategory
    {
        $category = ProductCategory::query()
            ->whereNull('deleted_at')
            ->where('parent_id', $parent?->getKey())
            ->whereRaw('LOWER(TRIM(name)) = ?', [mb_strtolower(trim($name))])
            ->first();

        if (! $category) {
            $category = new ProductCategory([
                'uuid' => (string) Str::uuid(),
                'parent_id' => $parent?->getKey(),
                'name' => $name,
                'slug' => 'pending-'.Str::uuid()->toString(),
                'status' => 'active',
            ]);
        }

        $category->forceFill([
            'parent_id' => $parent?->getKey(),
            'name' => $name,
            'sort_order' => $sortOrder,
            'status' => 'active',
        ])->save();

        $category->updateQuietly([
            'slug' => (Str::slug($category->name) ?: 'category').'-'.$category->getKey(),
        ]);

        return $category->refresh();
    }

    private function ensureOtherChildForParentCategories(): void
    {
        ProductCategory::query()
            ->whereNull('deleted_at')
            ->whereRaw('LOWER(TRIM(name)) <> ?', ['other'])
            ->whereHas('children', fn ($query) => $query->whereNull('deleted_at')->whereRaw('LOWER(TRIM(name)) <> ?', ['other']))
            ->orderBy('sort_order')
            ->orderBy('name')
            ->get()
            ->each(function (ProductCategory $parent): void {
                $this->createCategory('Other', $parent, 99);
            });
    }
}
