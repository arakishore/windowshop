<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('product_attribute_group_values', function (Blueprint $table) {
            $table->engine = 'InnoDB';
            $table->charset = 'utf8mb4';
            $table->collation = 'utf8mb4_unicode_ci';

            $table->id();
            $table->uuid('uuid')->unique();
            $table->foreignId('product_attribute_group_id');
            $table->string('name');
            $table->string('short_code', 20)->nullable()->index('product_attr_group_values_short_code_idx');
            $table->string('code');
            $table->text('description')->nullable();
            $table->string('swatch_hex', 7)->nullable();
            $table->string('status', 30)
                ->default('active')
                ->comment('active,inactive')
                ->index();
            $table->unsignedInteger('sort_order')->default(0)->index();
            $table->foreignId('created_by')->nullable()->constrained('users')->nullOnDelete();
            $table->foreignId('updated_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamps();

            $table->foreign('product_attribute_group_id', 'pagv_group_fk')
                ->references('id')
                ->on('product_attribute_groups')
                ->cascadeOnDelete();

            $table->unique(['product_attribute_group_id', 'code'], 'attribute_group_values_group_code_unique');
            $table->index(['product_attribute_group_id', 'status'], 'attribute_group_values_group_status_index');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('product_attribute_group_values');
    }
};
